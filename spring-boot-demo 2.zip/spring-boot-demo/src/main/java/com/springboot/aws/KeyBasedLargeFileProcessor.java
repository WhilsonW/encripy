package com.springboot.aws;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.CompressionAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcePGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyDataDecryptorFactoryBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyKeyEncryptionMethodGenerator;
import org.bouncycastle.util.io.Streams;

import java.io.*;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Iterator;


import com.springboot.aws.util.PGPExampleUtil;

/**
 *
 * @author jeff
 * @date 2020-08-11
 */
public class KeyBasedLargeFileProcessor {


    /**
     *
     * 解密方法
     *
     * 加密文件路径+加密文件名称, 私钥, "密码".toCharArray(), 解密后文件存放路径+解密后文件名称
     *
     * @param inputFileName
     * @param keyFileName
     * @param passwd
     * @param defaultFileName
     * @throws IOException
     * @throws NoSuchProviderException
     */
    private static void decryptFile(String inputFileName, String keyFileName, char[] passwd,
                                    String defaultFileName) throws IOException, NoSuchProviderException {

        InputStream in = new BufferedInputStream(new FileInputStream(inputFileName));
        InputStream keyIn = new BufferedInputStream(new FileInputStream(keyFileName));
        decryptFile(in, keyIn, passwd, defaultFileName);
        keyIn.close();
        in.close();
    }


    /**
     * decrypt the passed in message stream
     */
    private static void decryptFile(InputStream in,
                                    InputStream keyIn,
                                    char[] passwd,
                                    String defaultFileName) throws IOException, NoSuchProviderException {

        in = PGPUtil.getDecoderStream(in);
        try {
            JcaPGPObjectFactory pgpF = new JcaPGPObjectFactory(in);
            PGPEncryptedDataList enc;
            Object o = pgpF.nextObject();

            //
            // the first object might be a PGP marker packet.
            //
            if (o instanceof PGPEncryptedDataList) {
                enc = (PGPEncryptedDataList) o;
            } else {
                enc = (PGPEncryptedDataList) pgpF.nextObject();
            }

            //
            // find the secret key
            //

            Iterator it = enc.getEncryptedDataObjects();
            PGPPrivateKey sKey = null;
            PGPPublicKeyEncryptedData pbe = null;
            PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn), new JcaKeyFingerprintCalculator());

            while (sKey == null && it.hasNext()) {
                pbe = (PGPPublicKeyEncryptedData) it.next();
                sKey = PGPExampleUtil.findSecretKey(pgpSec, pbe.getKeyID(), passwd);
            }

            if (sKey == null) {
                throw new IllegalArgumentException("secret key for message not found.");
            }

            InputStream clear = pbe.getDataStream(new JcePublicKeyDataDecryptorFactoryBuilder().setProvider("BC").build(sKey));
            JcaPGPObjectFactory plainFact = new JcaPGPObjectFactory(clear);
            Object message = plainFact.nextObject();

            if (message instanceof PGPCompressedData) {
                PGPCompressedData cData = (PGPCompressedData) message;
                JcaPGPObjectFactory pgpFact = new JcaPGPObjectFactory(cData.getDataStream());
                message = pgpFact.nextObject();

            }

            if (message instanceof PGPLiteralData) {
                PGPLiteralData ld = (PGPLiteralData) message;
                String outFileName = ld.getFileName();
                if (outFileName.length() == 0) {
                    outFileName = defaultFileName;
                } /*else {

                    *//**
                     * modify 20160520
                     * set fileName
                     * 不同的系统可能源文件的包含的路径信息不同。
                     *//*

                    String separator = "";
                    if (outFileName.contains("/")) {
                        separator = "/";
                    } else if (outFileName.contains("\\")) {
                        separator = "\\";
                    }

//                    String fileName = outFileName.substring(outFileName.lastIndexOf(separator) + 1);
                    String fileName = "ddd.txt";

                    String defseparator = "";

                    if (defaultFileName.contains("/")) {
                        defseparator = "/";
                    } else if (defaultFileName.contains("\\")) {
                        defseparator = "\\";
                    }


                    defaultFileName = defaultFileName.substring(0, defaultFileName.lastIndexOf(defseparator));

                    outFileName = defaultFileName + File.separator + fileName;
                }*/


                InputStream unc = ld.getInputStream();

                OutputStream fOut = new BufferedOutputStream(new FileOutputStream(defaultFileName));

                Streams.pipeAll(unc, fOut);
                fOut.close();

            } else if (message instanceof PGPOnePassSignatureList) {
                throw new PGPException("encrypted message contains a signed message - not literal data.");
            } else {
                throw new PGPException("message is not a simple encrypted file - type unknown.");
            }


            if (pbe.isIntegrityProtected()) {

                if (!pbe.verify()) {
                    System.err.println("message failed integrity check");
                } else {
                    System.err.println("message integrity check passed");
                }

            } else {
                System.err.println("no message integrity check");
            }

        } catch (PGPException e) {
            System.err.println(e);
            if (e.getUnderlyingException() != null) {
                e.getUnderlyingException().printStackTrace();
            }
        }
    }

    /**
     *
     * 加密方法
     *
     * 需要加密的文件路径+需要加密的加密文件名称,加密后生成文件路径+生成加密文件名称","公钥",true,true
     *
     * @param outputFileName
     * @param inputFileName
     * @param encKeyFileName
     * @param armor
     * @param withIntegrityCheck
     * @throws IOException
     * @throws NoSuchProviderException
     * @throws PGPException
     */
    private static void encryptFile(String outputFileName,
                                    String inputFileName,
                                    String encKeyFileName,
                                    boolean armor,
                                    boolean withIntegrityCheck) throws IOException, NoSuchProviderException, PGPException {

        OutputStream out = new BufferedOutputStream(new FileOutputStream(outputFileName));

        PGPPublicKey encKey = PGPExampleUtil.readPublicKey(encKeyFileName);

        encryptFile(out, inputFileName, encKey, armor, withIntegrityCheck);

        out.close();

    }


    private static void encryptFile(OutputStream out, String fileName,
                                    PGPPublicKey encKey,
                                    boolean armor,
                                    boolean withIntegrityCheck) throws IOException, NoSuchProviderException {

        if (armor) {
            out = new ArmoredOutputStream(out);
        }

        try {

            byte[] bytes = PGPExampleUtil.compressFile(fileName, CompressionAlgorithmTags.ZIP);

            PGPEncryptedDataGenerator encGen = new PGPEncryptedDataGenerator(
                    new JcePGPDataEncryptorBuilder(PGPEncryptedData.CAST5).setWithIntegrityPacket(withIntegrityCheck).setSecureRandom(new SecureRandom()).setProvider("BC"));
            encGen.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(encKey).setProvider("BC"));

            OutputStream cOut = encGen.open(out, bytes.length);
            cOut.write(bytes);
            cOut.close();
            if (armor) {
                out.close();
            }

        } catch (PGPException e) {
            System.err.println(e);
            if (e.getUnderlyingException() != null) {
                e.getUnderlyingException().printStackTrace();
            }
        }
    }


    public static void main(String[] args) throws Exception {

        Security.addProvider(new BouncyCastleProvider());

        //加密文件
        encryptFile("/Users/wangxuan/Desktop/11/22/GSPJournalData_20210712022332_ocr.pgp", "/Users/wangxuan/Desktop/11/22/GSPJournalData_20210712022332.csv", "/Users/wangxuan/Desktop/11/22/ocr_encrypt_gsp.pub.asc", true, true);
        //解密文件
        decryptFile("/Users/wangxuan/Desktop/11/22/GSPJournalData_20210712022332.pgp", "/Users/wangxuan/Desktop/11/22/prv.asc", "123456".toCharArray(), "/Users/wangxuan/Desktop/11/22/GSPJournalData_20210712022332_pgp.csv");
//        decryptFile("/Users/wangxuan/Desktop/11/22/origin_file13.txt.pgp", "/Users/wangxuan/Desktop/11/22/prv.asc", "123456".toCharArray(), "/Users/wangxuan/Desktop/11/22/origin_file13.txt");
        /*if (args.length == 0) {
            System.err.println("usage: KeyBasedFileProcessor -e|-d [-a|ai] file [secretKeyFile passPhrase|pubKeyFile]");
            return;
        }

        if (args[0].equals("-e")) {
            if (args[1].equals("-a") || args[1].equals("-ai") || args[1].equals("-ia")) {
                encryptFile(args[2] + ".asc", args[2], args[3], true, (args[1].indexOf('i') > 0));
            } else if (args[1].equals("-i")) {
                encryptFile(args[2] + ".pgp", args[2], args[3], false, true);
            } else {
                encryptFile(args[1] + ".bpg", args[1], args[2], false, false);
            }
        } else if (args[0].equals("-d")) {
            //modify 20160520 set outFileName
            decryptFile(args[1], args[2], args[3].toCharArray(), args[4]);
        } else {
            System.err.println("usage: KeyBasedFileProcessor -d|-e [-a|ai] file [secretKeyFile passPhrase|pubKeyFile]");
        }*/

    }


}
